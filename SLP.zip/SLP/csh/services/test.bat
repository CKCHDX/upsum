#!/bin/bash
# Test Service Shortcut - Executes the Python test service
cd "$(cd "$(dirname "$0")" && pwd)/../.."
python3 csh/services/test_service.py
