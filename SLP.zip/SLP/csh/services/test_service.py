import time
import signal
import sys


def signal_handler(sig, frame):
    print("\nExiting gracefully...")
    sys.exit(0)


signal.signal(signal.SIGINT, signal_handler)

print("Infinite loop started. Press Ctrl+C to stop.")
try:
    counter = 0
    while True:
        counter += 1
        print(f"Running... (iteration {counter})")
        time.sleep(
            5)  # Sleep 5 seconds to avoid high CPU usage [web:44][web:48]
except KeyboardInterrupt:
    print("\nStopped by user.")
